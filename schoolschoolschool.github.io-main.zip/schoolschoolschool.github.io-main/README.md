# this is a site i made because i was bored  ![eppy kitty](https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS6LGAHMZXZDIzJOfhzRp5WDz5JjIzGzgYpig&s)


> # **Hi** [![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fnintendoboi22.github.io%2Fpancake.pookie.apple%2F&count_bg=%23AF11F6&title_bg=%235C5C5C&icon=github.svg&icon_color=%23AF11F6&title=Views&edge_flat=false)](https://hits.seeyoufarm.com)
![🥵](images/spicey.png)

> # TODO list
-  **Add more games**
-  [Google WebApp](https://support.google.com/googleplay/work/answer/9147423?hl=en)
---
- [discord](https://discord.gg/KAxqmAjTsm) ?

---

> # Game Owners

- [**3KH0**](https://github.com/3kh0/)⬅ INSPIRATION
#### 10 Minutes Till Dawn – Flanne, 2022
#### 1v1.LOL – JustPlay.LOL, 2020
#### 2048 – Gabriele Cirulli, 2014
#### Awesome Tanks – Alexander Gette, 2012
#### Awesome Tanks 2 – Alexander Gette, 2013
#### Basket Random – RHM Interactive, 2020
#### Basketball Stars – Madpuffers, 2019
#### BitLife – Candywriter, 2018
#### Boxing Random – RHM Interactive, 2019
#### BTD (Bloons Tower Defense Series) – Ninja Kiwi, 2007 onward
#### Burrito Bison – Juicy Beast, 2011
#### Challenge the Runners – (No reliable public information)
#### Chrome Dino – Google, 2014
#### Cookie Clicker – Orteil, 2013
#### Craft Mine – Crafted Games (unverified)
#### Deal or No Deal – Endemol Shine Group, various adaptations since 2005
#### Drift Hunters – Studionum43, 2017
#### Duck Life Series – Wix Games, 2008 onward
#### Eggy Car – Martin Magni, 2020
#### Evil Glitch – Not a Pixel, 2017
#### Flappy Bird – Dong Nguyen, 2013
#### FNAF (Five Nights at Freddy's Series) – Scott Cawthon, 2014 onward
#### Funny Shooter 2 – GoGoMan, 2023
#### Geometry Dash – RobTop Games, 2013
#### Google Snake – Google, 2017
#### Hextris – Logan Engstrom, 2014
#### Idle Breakout – Kodiqi, 2019
#### Idle Web Tycoon – (Information unavailable)
#### Impossible Quiz Series – Splapp-me-do, 2007
#### Jacksmith – Flipline Studios, 2012
#### JS Roulette – Various contributors (open-source)
#### Learn to Fly Series – Light Bringer Games, 2009 onward
#### Madalin Stunt Cars 2 – Madalin Games, 2015
#### Madalin Stunt Cars 3 – Madalin Games, 2018
#### Make Sure It’s Closed – J. Demers, 2019
#### Monkey Mart – TinyDobbins, 2022
#### Moto X3M – Madpuffers, 2015
#### Nintendo 64 – Nintendo, console released in 1996; specific games vary
#### OVO – Dedra Games, 2020
#### Papa Louie/Papa’s Series – Flipline Studios, 2007 onward
#### PC Breakdown – (Information unavailable)
#### Poly Track – (No widely available information)
#### Push Your Luck – (No widely available information)
#### Retro Bowl – New Star Games, 2020
#### Riddle School Seriereplaces – Jonochrome (JonBro), 2006-2016
#### Rooftopsnipers – (No widely available information)
#### Run Series – Player 03, 2008 onward
#### Rusty Submarine – (No widely available information)
#### Scratch Egg Inc – Inspired by Auxbrain’s Egg, Inc., 2016 (fan project)
#### Slope – Rob Kay, 2014
#### Snake.io – Kooapps Games, 2016
#### Soccer Random – RHM Interactive, 2020
#### Sort the Court – Graeme Borland, 2017
#### Space Company – (Independent project; no verified public info)
#### Subway Surfers – SYBO Games & Kiloo, 2012
#### Superhot – SUPERHOT Team, 2016
#### Tanuki Sunset – Rewind Games, 2020
#### Territorial.io – David Tschacher, 2021
#### There is No Game – Draw Me a Pixel, 2015
#### Time Shooter Series – GoGoMan, 2021 onward
#### Tiny Fishing – Inlogic Games, 2020
#### Tomb of the Mask – Happymagenta UAB, 2016
#### Tunnel Rush Series – Royale Gamers, 2018
#### Unicycle Hero – Unept, 2017
#### Volley Random – RHM Interactive, 2020
#### Wheely Series – Pegas Games, 2014 onward

  - **Unlisted Games**
        -[I(*and future partners*) do not take credit for the games in this website, they are not created or made by us]
- *pls dont sue me 🥺*

> # Links
1. **[Main](https://nintendoboi22.github.io)**
2. **[Main 2](https://nintendoboi222.github.io)**
3. **[Redesign](https://nintendoboi222.github.io/redesign-test)**
  
> # DMCA
- **[DMCA, if needed](https://nintendoboi222.github.io/licence-stuff/dmca)**
---
> ## Font Licence
- **[Orbitron](https://fonts.google.com/specimen/Orbitron/license?categoryFilters=Appearance:%2FTheme%2FTechno)**
